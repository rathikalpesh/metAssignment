var clg =[];
var setinfo=function(){
    //if('x1'=="" || 'x2'=="" || 'x3'=="" || 'x4'=="")
    //alert()
    var a = document.getElementById("x1").value;
    var b = document.getElementById("x2").value;
    var c = document.getElementById("x3").value;
    var d = document.getElementById("x4").value;
    
    var student = {
        name: a,
        Rollno: b,
        Age:c,
        Marks:d
    }


    clg[clg.length]=student;
}
    //var param = JSON.stringify(student)

    
    // if(clg.length>0)
var getinfo=function(){   
        var x=""
        for(val of clg)
        {
            //console.log(val);
            x=x+`
            <tr>
                <td>${val.name}</td>
                <td>${val.Rollno}</td>
                <td>${val.Age}</td>
                <td>${val.Marks}</td>
            </tr>
            `
        }
        console.log(x);
        document.getElementById('result').innerHTML=x;
}

    // console.log(clg);
